from setuptools import find_packages, setup

package_name = 'turtle_lesson'
setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='Mechatronics Training',
    maintainer_email='training@example.com',
    description='ROS 2 Humble topic communication exercises.',
    license='Apache-2.0',
    entry_points={'console_scripts': [
        'velocity = turtle_lesson.velocity_publisher:main',
        'pose = turtle_lesson.pose_listener:main',
        'goal = turtle_lesson.goal_controller:main',
    ]},
)
