from math import atan2, cos, hypot, sin


def velocity_to_goal(pose, goal_x, goal_y):
    """位置・向きと目的地から，前進速度と旋回速度を返す配布関数．"""
    dx = goal_x - pose.x
    dy = goal_y - pose.y
    distance = hypot(dx, dy)
    if distance < 0.15:
        return 0.0, 0.0
    heading = atan2(dy, dx)
    angle = atan2(sin(heading - pose.theta), cos(heading - pose.theta))
    linear = min(1.0, distance) * max(0.0, cos(angle))
    angular = max(-2.0, min(2.0, 4.0 * angle))
    return linear, angular
