import rclpy
from rclpy.node import Node
from rclpy.executors import ExternalShutdownException
from geometry_msgs.msg import Twist


class VelocityPublisher(Node):
    def __init__(self):
        super().__init__('velocity_publisher')
        # TODO: Twistを/turtle1/cmd_velへ送るPublisherを作る．
        # TODO: 0.1秒おきにon_timerを呼ぶタイマーを作る．

    def on_timer(self):
        # TODO: Twistを作り，速度を入れて送信する．
        pass


def main(args=None):
    rclpy.init(args=args)
    node = VelocityPublisher()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()
