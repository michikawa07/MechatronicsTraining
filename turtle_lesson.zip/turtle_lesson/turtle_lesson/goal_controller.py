import rclpy
from rclpy.node import Node
from rclpy.executors import ExternalShutdownException
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose
from turtle_lesson.steering import velocity_to_goal


class GoalController(Node):
    def __init__(self):
        super().__init__('goal_controller')
        self.goal_x, self.goal_y = 8.0, 8.0
        self.pose = None
        # TODO: 速度を送るPublisherを作る．
        # TODO: 位置・向きを受け取るSubscriberを作る．
        # TODO: 0.1秒おきにon_timerを呼ぶタイマーを作る．

    def on_pose(self, msg):
        # TODO: 受信した状態をself.poseに保存する．
        pass

    def on_timer(self):
        if self.pose is None:
            return
        linear, angular = velocity_to_goal(
            self.pose, self.goal_x, self.goal_y)
        # TODO: 計算したlinear，angularをTwistに入れて送信する．


def main(args=None):
    rclpy.init(args=args)
    node = GoalController()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()
