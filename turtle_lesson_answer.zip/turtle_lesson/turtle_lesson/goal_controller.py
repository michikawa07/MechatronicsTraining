import rclpy
from rclpy.node import Node
from rclpy.executors import ExternalShutdownException
from geometry_msgs.msg import Twist
from turtlesim.msg import Pose
from turtle_lesson.steering import velocity_to_goal


class GoalController(Node):
    def __init__(self):
        super().__init__('goal_controller')
        self.goal_x, self.goal_y = 8.0, 8.0
        self.pose = None
        self.pub = self.create_publisher(
            Twist, '/turtle1/cmd_vel', 10)
        self.sub = self.create_subscription(
            Pose, '/turtle1/pose', self.on_pose, 10)
        self.timer = self.create_timer(0.1, self.on_timer)

    def on_pose(self, msg):
        self.pose = msg

    def on_timer(self):
        if self.pose is None:
            return
        linear, angular = velocity_to_goal(
            self.pose, self.goal_x, self.goal_y)
        msg = Twist()
        msg.linear.x = linear
        msg.angular.z = angular
        self.pub.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = GoalController()
    try:
        rclpy.spin(node)
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        node.destroy_node()
        rclpy.try_shutdown()
